package com.dicoding.mydicodingevent.fragment

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.mydicodingevent.data.response.ListEventsItem
import com.dicoding.mydicodingevent.databinding.FragmentFinishedEventBinding
import com.dicoding.mydicodingevent.ui.EventAdapter
import com.dicoding.mydicodingevent.ui.MainViewModel

class UpcomingEventFragment : Fragment() {

    private lateinit var binding: FragmentFinishedEventBinding
    private lateinit var viewModel: MainViewModel

    companion object {
        private const val TAG = "FinishedEventFragment"
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentFinishedEventBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[MainViewModel::class.java]

        setupRecyclerView()
        viewModel.findListEventsItem("1")

        viewModel.listEventsItem.observe(viewLifecycleOwner) { events ->
            if (events != null) {
                setEventData(events)
            } else {
                Log.e(TAG, "Failed to load event data")
            }
        }

        viewModel.isLoading.observe(viewLifecycleOwner) { isLoading ->
            showLoading(isLoading)
        }
    }

    private fun setupRecyclerView() {
        val layoutManager = LinearLayoutManager(requireContext())
        binding.rvEvent.layoutManager = layoutManager
        val itemDecoration = DividerItemDecoration(requireContext(), layoutManager.orientation)
        binding.rvEvent.addItemDecoration(itemDecoration)
    }

    private fun setEventData(events: List<ListEventsItem>) {
        val adapter = EventAdapter(events) { isLoading ->
            showLoading(isLoading)
        }
        binding.rvEvent.adapter = adapter
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) View.VISIBLE else View.GONE
    }
}

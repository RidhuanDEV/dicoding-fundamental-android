package com.dicoding.mydicodingevent.data.retrofit

import android.net.http.UrlRequest.Status
import com.dicoding.mydicodingevent.data.response.EventResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiService {
    @GET("events")
    fun getEvent(
            @Query("active") active: String
    ) : Call<EventResponse>
}
package com.dicoding.mydicodingevent.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.dicoding.mydicodingevent.R
import com.dicoding.mydicodingevent.databinding.ActivityMainBinding
import com.dicoding.mydicodingevent.fragment.FinishedEventFragment
import com.dicoding.mydicodingevent.fragment.UpcomingEventFragment

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var viewModel: MainViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        viewModel = ViewModelProvider(this)[MainViewModel::class.java]

        supportActionBar?.hide()
        setupBottomNavigation()

        if (savedInstanceState == null) {
            loadFragment(UpcomingEventFragment())
        }
    }

    private fun setupBottomNavigation() {
        binding.navView.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.upcoming_event_fragment -> {
                    loadFragment(UpcomingEventFragment())
                    true
                }
                R.id.finished_event_fragment -> {
                    loadFragment(FinishedEventFragment())
                    true
                }
                else -> false
            }
        }
    }

    private fun loadFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.container, fragment)
        transaction.commit()
    }
}

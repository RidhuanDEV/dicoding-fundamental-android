package com.dicoding.mydicodingevent.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import com.bumptech.glide.Glide
import com.dicoding.mydicodingevent.data.response.ListEventsItem
import com.dicoding.mydicodingevent.databinding.ActivityDetailEventBinding

class DetailEventActivity : AppCompatActivity() {

    private lateinit var binding: ActivityDetailEventBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailEventBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val event: ListEventsItem? = intent.getParcelableExtra("event_data_list")
        if (event != null) {
            showLoading(true)
            showEventDetails(event)
        } else {
            handleError("Event data is missing")
        }

        binding.btnOpenLink.setOnClickListener {
            event?.let {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(event.link))
                startActivity(intent)
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showEventDetails(event: ListEventsItem) {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                Glide.with(this)
                    .load(event.mediaCover)
                    .into(binding.imgEventCover)

                binding.tvEventName.text = event.name
                binding.tvEventOrganizer.text = "Event Organizer: ${event.ownerName}"
                binding.tvEventTime.text = "Event Time: ${event.beginTime}"

                val remainingQuota = event.quota - event.registrants
                binding.tvEventQuota.text = "Remaining Quota: $remainingQuota"
                binding.tvEventDescription.text = "Event Description:\n" + HtmlCompat.fromHtml(
                    event.description,
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
            } catch (e: Exception) {
                handleError("Failed to load event details")
            } finally {
                showLoading(false)
            }
        }, 1000)
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility = if (isLoading) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun handleError(message: String) {
        showLoading(false)
        binding.tvEventDescription.text = message
        binding.btnOpenLink.isEnabled = false
    }
}

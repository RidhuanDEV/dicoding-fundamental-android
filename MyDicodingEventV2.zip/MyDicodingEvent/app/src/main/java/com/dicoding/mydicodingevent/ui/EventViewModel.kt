package com.dicoding.mydicodingevent.ui

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.mydicodingevent.data.EventRepository
import com.dicoding.mydicodingevent.data.local.entity.EventEntity
import com.dicoding.mydicodingevent.data.local.room.EventDao
import kotlinx.coroutines.launch

class EventViewModel(private val eventRepository: EventRepository) : ViewModel() {
    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> get() = _isLoading

    fun setLoading(isLoading: Boolean) {
        _isLoading.value = isLoading
    }


    fun getBookmarkedEvent() = eventRepository.getBookmarkedEvent()


    fun getBookmark(id: String): LiveData<EventEntity> {
        return eventRepository.getBookmark(id)
    }

    fun saveEvent(event: EventEntity) {
        viewModelScope.launch {
            eventRepository.insertEvent(event)
        }
    }

    fun deleteEvent(event: EventEntity) {
        viewModelScope.launch {
            eventRepository.deleteEvent(event)
        }
    }



}

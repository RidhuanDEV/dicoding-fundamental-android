package com.dicoding.mydicodingevent.data.local.entity

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Entity(tableName = "Event")
@Parcelize
data class  EventEntity(
    @PrimaryKey(autoGenerate = false)
    var id: String = "",
    var name: String = "",
    var mediaCover: String? = null,
    val ownerName: String, 
    val beginTime: String, 
    val quota: Int, 
    val registrants: Int, 
    val description: String, 
    val link: String, 
    @field:ColumnInfo(name = "bookmarked")
    var isBookmarked: Boolean
) : Parcelable


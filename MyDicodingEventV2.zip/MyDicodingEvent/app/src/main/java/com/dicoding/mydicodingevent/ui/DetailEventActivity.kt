package com.dicoding.mydicodingevent.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.text.HtmlCompat
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.bumptech.glide.Glide
import com.dicoding.mydicodingevent.R
import com.dicoding.mydicodingevent.data.local.entity.EventEntity
import com.dicoding.mydicodingevent.data.response.ListEventsItem
import com.dicoding.mydicodingevent.databinding.ActivityDetailEventBinding
import kotlinx.coroutines.launch

class DetailEventActivity : AppCompatActivity() {
    private val itemDataList: String = "event_data_list"
    private lateinit var database: EventEntity
    private lateinit var binding: ActivityDetailEventBinding
    private lateinit var viewModel: EventViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailEventBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val factory = ViewModelFactory.getInstance(this)
        viewModel = ViewModelProvider(this, factory)[EventViewModel::class.java]

        val eventItem: ListEventsItem? = intent.getParcelableExtra(itemDataList)

        if (eventItem != null) {
            showLoading(true)
            showEventDetails(eventItem)
            Log.d("DetailEventActivity", "Event data: $eventItem") // log untuk lihat data
            database = EventEntity(
                id = eventItem.id.toString(),
                name = eventItem.name,
                mediaCover = eventItem.mediaCover,
                ownerName = eventItem.ownerName, 
                beginTime = eventItem.beginTime, 
                quota = eventItem.quota, 
                registrants = eventItem.registrants, 
                description = eventItem.description, 
                link = eventItem.link, 
                isBookmarked = false
            )

        } else {
            handleError("Event data is missing")
        }

        binding.btnOpenLink.setOnClickListener {
            eventItem?.let {
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(it.link))
                startActivity(intent)
            }
        }

        val ivBookmark = binding.fabFavorite
        ivBookmark.setOnClickListener {

            updateBookmarkIcon(database)
        }
    }

    @SuppressLint("SetTextI18n")
    private fun showEventDetails(
        event: ListEventsItem,
        ) {
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                Glide.with(this)
                    .load(event.mediaCover)
                    .into(binding.imgEventCover)

                binding.tvEventName.text = event.name
                binding.tvEventOrganizer.text = "Event Organizer: ${event.ownerName}"
                binding.tvEventTime.text = "Event Time: ${event.beginTime}"

                val remainingQuota = event.quota - event.registrants
                binding.tvEventQuota.text = "Remaining Quota: $remainingQuota"
                binding.tvEventDescription.text = "Event Description:\n" + HtmlCompat.fromHtml(
                    event.description,
                    HtmlCompat.FROM_HTML_MODE_LEGACY
                )
                viewModel.getBookmark(event.id.toString()).observe(this) { eventEntity ->
                    if (eventEntity != null) {
                        binding.fabFavorite.setImageResource(R.drawable.baseline_favorite_24)
                    } else {
                        binding.fabFavorite.setImageResource(R.drawable.baseline_favorite_border_24)
                    }
                }

            } catch (e: Exception) {
                handleError("Failed to load event details")
            } finally {
                showLoading(false)
            }
        }, 1000)
    }

    private fun updateBookmarkIcon(eventEntity: EventEntity) {
        lifecycleScope.launch {
            try {
                if (eventEntity.isBookmarked) {
                    viewModel.deleteEvent(eventEntity)
                    binding.fabFavorite.setImageResource(R.drawable.baseline_favorite_border_24)

                } else {
                    database.isBookmarked = true
                    viewModel.saveEvent(eventEntity)
                    binding.fabFavorite.setImageResource(R.drawable.baseline_favorite_24)

                }
            } catch (e: Exception) {
                Toast.makeText(this@DetailEventActivity, "Failed to load Data",Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showLoading(isLoading: Boolean) {
        binding.progressBar.visibility =
            if (isLoading) android.view.View.VISIBLE else android.view.View.GONE
    }

    private fun handleError(message: String) {
        showLoading(false)
        binding.tvEventDescription.text = message
        binding.btnOpenLink.isEnabled = false
    }


}